# HackerTube sample for NerdLore's demo mode

A small sample of the HackerTube export (https://hackertube.org/data), made on 2026-11-03 with
scripts/make_demo_sample.py. 628 of 6454 videos and 2122 of 39834
mentions. Video rows are copied unchanged. Mention rows keep only the fields NerdLore reads
(video, stance, month, thread title, short quote and link): no usernames or full comments.

HackerTube's data is derived from the open-index/hacker-news dataset
(https://huggingface.co/datasets/open-index/hacker-news, Hacker News data by Y Combinator) and
licensed under the Open Data Commons Attribution License (ODC-By 1.0):
https://opendatacommons.org/licenses/by/1-0/

Hacker News comments quoted here remain the work of their authors. HackerTube's labels were
written by an LLM. NerdLore is not affiliated with HackerTube, Hacker News or Y Combinator.

This sample contains no YouTube data. The view counts NerdLore shows in demo mode are made
up on your computer when you press "Try the demo".
